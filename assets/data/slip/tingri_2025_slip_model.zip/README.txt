2025 Dingri (Tingri), Tibet earthquake: slip model
==================================================

The Dengmocuo fault on the near-field products' own trace, dipping west at 50 degrees at the surface, flattening to 35 degrees at 25 km, and a western antithetic fault dipping 45 degrees east with normal slip only, ending on the main fault, both to 20 km in a layered crust (CRUST1.0); Sentinel-1 interferograms (tracks 012 and 121) and ALOS-2 path 47's interferogram and azimuth offsets (He, Feng & Yun 2025), 12 GNSS stations (Li et al. 2025); rank 14 by blocked cross-validation. The bottom at 20 km is a modelling choice: Mw about 7.02-7.09 for bottoms at 15-30 km.
From https://eitanrapa.github.io/research/slip-models/ (exported 2026-11-05).

Faults (Mw from the inversion's own layered rigidity, as on the page; rake slip-weighted):
  - Dengmocuo fault: Mw 7.05; 68 km long, to 20 km, dips 38-57 deg to the W;
    trace listed from S to N (azimuth 3 deg), so its left-hand block is the W one, the hanging wall;
    rake -76 deg (normal), peak slip 3.0 m; 196 nodes, 335 triangles
  - Western graben fault: Mw 5.88; 48 km long, to 20 km, dips 38-75 deg to the ESE;
    trace listed from SSW to NNE (azimuth 12 deg), so its left-hand block is the WNW one, the footwall;
    rake -90 deg (normal), peak slip 0.2 m; 157 nodes, 228 triangles
  all faults: Mw 7.06 (the faults' moments summed).

Files
  *_nodes.csv      one row per mesh node. Slip is defined at the nodes and varies linearly over each
                   triangle between its three corners: this is what the inversion solved for.
  *_triangles.csv  one row per triangle: its corners, as node ids (node1-3 = rows of *_nodes.csv) and as
                   lon/lat/depth, its slip (the mean of its corners', i.e. the linear field's average over
                   the triangle; use these rows for a piecewise-constant model), its own plane's strike and
                   dip, and the rake.

Columns
  lon, lat         degrees, WGS84
  depth_km         km below the model's flat free surface, positive down
  slip_m           slip magnitude, m
  ss_m, ds_m       the inversion's own components, in the frame of each fault's trace as listed above:
                   ss_m > 0 is left-lateral, ds_m > 0 moves the trace's LEFT-hand block up-dip relative to
                   the right-hand one. Continuous along each fault: use these to map or interpolate slip.
  strike_deg, dip_deg, rake_deg  (triangles only)
                   Aki & Richards, from the triangle's own plane: strike clockwise from north with the
                   fault dipping to its right, dip 0-90, rake the hanging wall's slip relative to the
                   footwall measured in the plane from the strike direction (0 left-lateral, +-180
                   right-lateral, 90 reverse, -90 normal). A vertical triangle (dip within 0.01 deg of
                   90) takes its strike along the trace as listed.
                   Where a fault is nearly vertical its triangles tilt by fractions of a degree either way
                   (the trace curves), so this strike can flip by 180 deg between neighbours, and the sign
                   of the rake's dip-slip part with it, for the same motion. Map ss_m / ds_m instead.
  area_km2         (triangles only) the triangle's area

