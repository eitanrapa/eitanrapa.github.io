2026 San Sebastián, Venezuela earthquake: slip model
====================================================

Model 4e: the San Sebastián fault vertical to 35 km, a layered crust with a softer north block above 25 km (shear-modulus ratio 1.59, the exact bimaterial solution), seven InSAR tracks (four NISAR, our own processing and ionospheric screens; three ALOS-2).
From https://eitanrapa.github.io/research/slip-models/ (exported 2026-11-02).

Faults (Mw from the inversion's own layered rigidity, as on the page; rake slip-weighted):
  - San Sebastián fault: Mw 7.60; 263 km long, to 35 km, vertical;
    trace listed from W to E (azimuth 84 deg), so its left-hand block is the N one;
    rake 180 deg (right-lateral), peak slip 3.4 m; 1384 nodes, 2569 triangles

Files
  *_nodes.csv      one row per mesh node. Slip is defined at the nodes and varies linearly over each
                   triangle between its three corners: this is what the inversion solved for.
  *_triangles.csv  one row per triangle: its corners, as node ids (node1-3 = rows of *_nodes.csv) and as
                   lon/lat/depth, its slip (the mean of its corners', i.e. the linear field's average over
                   the triangle; use these rows for a piecewise-constant model), its own plane's strike and
                   dip, and the rake.

Columns
  lon, lat         degrees, WGS84
  depth_km         km below the model's flat free surface, positive down
  slip_m           slip magnitude, m
  ss_m, ds_m       the inversion's own components, in the frame of each fault's trace as listed above:
                   ss_m > 0 is left-lateral, ds_m > 0 moves the trace's LEFT-hand block up-dip relative to
                   the right-hand one. Continuous along each fault: use these to map or interpolate slip.
  strike_deg, dip_deg, rake_deg  (triangles only)
                   Aki & Richards, from the triangle's own plane: strike clockwise from north with the
                   fault dipping to its right, dip 0-90, rake the hanging wall's slip relative to the
                   footwall measured in the plane from the strike direction (0 left-lateral, +-180
                   right-lateral, 90 reverse, -90 normal). A vertical triangle (dip within 0.01 deg of
                   90) takes its strike along the trace as listed.
                   Where a fault is nearly vertical its triangles tilt by fractions of a degree either way
                   (the trace curves), so this strike can flip by 180 deg between neighbours, and the sign
                   of the rake's dip-slip part with it, for the same motion. Map ss_m / ds_m instead.
  area_km2         (triangles only) the triangle's area

