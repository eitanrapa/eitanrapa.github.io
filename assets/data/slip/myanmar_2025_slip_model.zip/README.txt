2025 Mandalay, Myanmar earthquake: slip model
=============================================

The Sagaing fault, 504 km, vertical in the south and dipping east to 60 degrees in the north, to 30 km depth, in a layered crust (CRUST1.0) with the west block 1.3 times softer above 10 km (the exact bimaterial solution); two ALOS-2 interferograms and Sentinel-1 and LuTan-1 range and azimuth offsets (Xu et al. 2025); rank 88 by blocked cross-validation. Mw is with the two sides' harmonic-mean rigidity above 10 km; with the east (reference) crust's rigidity it is 7.90.
From https://eitanrapa.github.io/research/slip-models/ (exported 2026-11-05).

Faults (Mw from the inversion's own layered rigidity, as on the page; rake slip-weighted):
  - Sagaing fault: Mw 7.88; 504 km long, to 30 km, dips 55-90 deg to the E;
    trace listed from S to N (azimuth 354 deg), so its left-hand block is the W one, the footwall;
    rake -179 deg (right-lateral), peak slip 5.6 m; 1388 nodes, 2492 triangles

Files
  *_nodes.csv      one row per mesh node. Slip is defined at the nodes and varies linearly over each
                   triangle between its three corners: this is what the inversion solved for.
  *_triangles.csv  one row per triangle: its corners, as node ids (node1-3 = rows of *_nodes.csv) and as
                   lon/lat/depth, its slip (the mean of its corners', i.e. the linear field's average over
                   the triangle; use these rows for a piecewise-constant model), its own plane's strike and
                   dip, and the rake.

Columns
  lon, lat         degrees, WGS84
  depth_km         km below the model's flat free surface, positive down
  slip_m           slip magnitude, m
  ss_m, ds_m       the inversion's own components, in the frame of each fault's trace as listed above:
                   ss_m > 0 is left-lateral, ds_m > 0 moves the trace's LEFT-hand block up-dip relative to
                   the right-hand one. Continuous along each fault: use these to map or interpolate slip.
  strike_deg, dip_deg, rake_deg  (triangles only)
                   Aki & Richards, from the triangle's own plane: strike clockwise from north with the
                   fault dipping to its right, dip 0-90, rake the hanging wall's slip relative to the
                   footwall measured in the plane from the strike direction (0 left-lateral, +-180
                   right-lateral, 90 reverse, -90 normal). A vertical triangle (dip within 0.01 deg of
                   90) takes its strike along the trace as listed.
                   Where a fault is nearly vertical its triangles tilt by fractions of a degree either way
                   (the trace curves), so this strike can flip by 180 deg between neighbours, and the sign
                   of the rake's dip-slip part with it, for the same motion. Map ss_m / ds_m instead.
  area_km2         (triangles only) the triangle's area

