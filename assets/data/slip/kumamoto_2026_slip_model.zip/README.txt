2026 Kumamoto, Japan earthquake: slip model
===========================================

The Hinagu fault zone on GSI's mapped surface displacement boundary, 5 km past each end, dipping north-west over four 11.5 km segments south-west to north-east: 70 degrees at the surface to 50 at 20 km, the same, 65 to 75, and 80; to 20 km in a layered crust (CRUST1.0). NISAR interferograms on tracks 024 and 125 (ascending) and 003 and 104 (descending) processed by us, spanning the event and ending 16-24 days after it, and 131 GNSS stations (NGL) over days 16-24, so the model is the earthquake plus about three weeks; rank 28.5 by blocked cross-validation. The bottom at 20 km is a modelling choice: Mw 6.82-6.92 for bottoms at 14-28 km.
From https://eitanrapa.github.io/research/slip-models/ (exported 2026-11-06).

Faults (Mw from the inversion's own layered rigidity, as on the page; rake slip-weighted):
  - Hinagu fault zone: Mw 6.84; 45 km long, to 20 km, dips 49-88 deg to the WNW;
    trace listed from SSW to NNE (azimuth 30 deg), so its left-hand block is the WNW one, the hanging wall;
    rake -168 deg (right-lateral), peak slip 2.8 m; 312 nodes, 557 triangles

Files
  *_nodes.csv      one row per mesh node. Slip is defined at the nodes and varies linearly over each
                   triangle between its three corners: this is what the inversion solved for.
  *_triangles.csv  one row per triangle: its corners, as node ids (node1-3 = rows of *_nodes.csv) and as
                   lon/lat/depth, its slip (the mean of its corners', i.e. the linear field's average over
                   the triangle; use these rows for a piecewise-constant model), its own plane's strike and
                   dip, and the rake.

Columns
  lon, lat         degrees, WGS84
  depth_km         km below the model's flat free surface, positive down
  slip_m           slip magnitude, m
  ss_m, ds_m       the inversion's own components, in the frame of each fault's trace as listed above:
                   ss_m > 0 is left-lateral, ds_m > 0 moves the trace's LEFT-hand block up-dip relative to
                   the right-hand one. Continuous along each fault: use these to map or interpolate slip.
  strike_deg, dip_deg, rake_deg  (triangles only)
                   Aki & Richards, from the triangle's own plane: strike clockwise from north with the
                   fault dipping to its right, dip 0-90, rake the hanging wall's slip relative to the
                   footwall measured in the plane from the strike direction (0 left-lateral, +-180
                   right-lateral, 90 reverse, -90 normal). A vertical triangle (dip within 0.01 deg of
                   90) takes its strike along the trace as listed.
                   Where a fault is nearly vertical its triangles tilt by fractions of a degree either way
                   (the trace curves), so this strike can flip by 180 deg between neighbours, and the sign
                   of the rake's dip-slip part with it, for the same motion. Map ss_m / ds_m instead.
  area_km2         (triangles only) the triangle's area

