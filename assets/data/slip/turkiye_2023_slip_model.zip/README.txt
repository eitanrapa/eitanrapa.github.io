2023 Kahramanmaraş, Türkiye earthquake doublet: slip model
==========================================================

Both events in one inversion: the East Anatolian fault (event 1) and the Çardak fault (event 2) with their branches, in a layered crust; Sentinel-1 InSAR and pixel offsets.
From https://eitanrapa.github.io/research/slip-models/ (exported 2026-11-02).

Faults (Mw from the inversion's own layered rigidity, as on the page; rake slip-weighted):
  - East Anatolian Fault (event 1): Mw 7.83; 368 km long, to 26 km, dips 73-90 deg, mostly vertical;
    trace listed from SW to NE (azimuth 48 deg), so its left-hand block is the NW one;
    rake 0 deg (left-lateral), peak slip 8.0 m; 1073 nodes, 1915 triangles
  - Narlı fault (event 1): Mw 6.70; 37 km long, to 26 km, vertical;
    trace listed from SSW to NNE (azimuth 30 deg), so its left-hand block is the WNW one;
    rake 0 deg (left-lateral), peak slip 1.5 m; 142 nodes, 243 triangles
  - Çardak fault (event 2): Mw 7.69; 171 km long, to 26 km, dips 57-76 deg to the N;
    trace listed from W to E (azimuth 80 deg), so its left-hand block is the N one, the hanging wall;
    rake -3 deg (left-lateral), peak slip 8.4 m; 530 nodes, 942 triangles
  - N–S strand (event 2): Mw 6.11; 21 km long, to 26 km, dips 73-90 deg, mostly vertical;
    trace listed from S to N (azimuth 2 deg), so its left-hand block is the W one;
    rake -87 deg (normal), peak slip 0.4 m; 84 nodes, 138 triangles
  event 1: Mw 7.84; event 2: Mw 7.69 (the faults' moments summed).

Files
  *_nodes.csv      one row per mesh node. Slip is defined at the nodes and varies linearly over each
                   triangle between its three corners: this is what the inversion solved for.
  *_triangles.csv  one row per triangle: its corners, as node ids (node1-3 = rows of *_nodes.csv) and as
                   lon/lat/depth, its slip (the mean of its corners', i.e. the linear field's average over
                   the triangle; use these rows for a piecewise-constant model), its own plane's strike and
                   dip, and the rake.

Columns
  lon, lat         degrees, WGS84
  depth_km         km below the model's flat free surface, positive down
  slip_m           slip magnitude, m
  ss_m, ds_m       the inversion's own components, in the frame of each fault's trace as listed above:
                   ss_m > 0 is left-lateral, ds_m > 0 moves the trace's LEFT-hand block up-dip relative to
                   the right-hand one. Continuous along each fault: use these to map or interpolate slip.
  strike_deg, dip_deg, rake_deg  (triangles only)
                   Aki & Richards, from the triangle's own plane: strike clockwise from north with the
                   fault dipping to its right, dip 0-90, rake the hanging wall's slip relative to the
                   footwall measured in the plane from the strike direction (0 left-lateral, +-180
                   right-lateral, 90 reverse, -90 normal). A vertical triangle (dip within 0.01 deg of
                   90) takes its strike along the trace as listed.
                   Where a fault is nearly vertical its triangles tilt by fractions of a degree either way
                   (the trace curves), so this strike can flip by 180 deg between neighbours, and the sign
                   of the rake's dip-slip part with it, for the same motion. Map ss_m / ds_m instead.
  area_km2         (triangles only) the triangle's area

