2024 Noto, Japan earthquake: slip model
=======================================

A single fault along the Noto peninsula's north coast, on Enomoto & Kaneko (2025)'s offshore segments stitched into one line, 5 km past each end, dipping south-east at 50 degrees at the surface to 30 at 20 km; to 20 km in a layered crust (CRUST1.0). ALOS-2 range offsets on tracks 121, 127 and 026 (Xu et al. 2024), ALOS-2 interferograms on the same pairs (Guo et al. 2025) beyond 15-25 km of the line, and NGL's GNSS at 365 stations over days 1-5; rank 48 by blocked cross-validation. The offshore line is not mapped in a public file. The bottom at 20 km is a modelling choice: Mw 7.59-7.61 for bottoms at 16-24 km.
From https://eitanrapa.github.io/research/slip-models/ (exported 2026-11-06).

Faults (Mw from the inversion's own layered rigidity, as on the page; rake slip-weighted):
  - Noto north-coast faults: Mw 7.59; 146 km long, to 20 km, dips 30-58 deg to the SE;
    trace listed from SW to NE (azimuth 51 deg), so its left-hand block is the NW one, the footwall;
    rake 117 deg (oblique reverse-right-lateral), peak slip 7.7 m; 422 nodes, 750 triangles

Files
  *_nodes.csv      one row per mesh node. Slip is defined at the nodes and varies linearly over each
                   triangle between its three corners: this is what the inversion solved for.
  *_triangles.csv  one row per triangle: its corners, as node ids (node1-3 = rows of *_nodes.csv) and as
                   lon/lat/depth, its slip (the mean of its corners', i.e. the linear field's average over
                   the triangle; use these rows for a piecewise-constant model), its own plane's strike and
                   dip, and the rake.

Columns
  lon, lat         degrees, WGS84
  depth_km         km below the model's flat free surface, positive down
  slip_m           slip magnitude, m
  ss_m, ds_m       the inversion's own components, in the frame of each fault's trace as listed above:
                   ss_m > 0 is left-lateral, ds_m > 0 moves the trace's LEFT-hand block up-dip relative to
                   the right-hand one. Continuous along each fault: use these to map or interpolate slip.
  strike_deg, dip_deg, rake_deg  (triangles only)
                   Aki & Richards, from the triangle's own plane: strike clockwise from north with the
                   fault dipping to its right, dip 0-90, rake the hanging wall's slip relative to the
                   footwall measured in the plane from the strike direction (0 left-lateral, +-180
                   right-lateral, 90 reverse, -90 normal). A vertical triangle (dip within 0.01 deg of
                   90) takes its strike along the trace as listed.
                   Where a fault is nearly vertical its triangles tilt by fractions of a degree either way
                   (the trace curves), so this strike can flip by 180 deg between neighbours, and the sign
                   of the rake's dip-slip part with it, for the same motion. Map ss_m / ds_m instead.
  area_km2         (triangles only) the triangle's area

