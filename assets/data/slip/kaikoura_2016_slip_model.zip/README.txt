2016 Kaikōura, New Zealand earthquake: slip model
=================================================

Xu et al. (2018)'s six fault segments to 25 km depth in a layered crust (CRUST1.0): the Needles-Kekerengu-Jordan line dipping north-west (its north-east part steep near the surface, 70 degrees, flattening to 20 degrees at 25 km; its south-west part 45 degrees), the Stone Jug fault dipping 30 degrees east-north-east, the Papatea, Hundalee, North Leader and Humps faults vertical; ALOS-2 and Sentinel-1 InSAR (UCSD), NGL GNSS and Xu (2026)'s 3-D displacement field; rank 44 by blocked cross-validation.
From https://eitanrapa.github.io/research/slip-models/ (exported 2026-11-04).

Faults (Mw from the inversion's own layered rigidity, as on the page; rake slip-weighted):
  - Needles–Kekerengu–Jordan line: Mw 7.82; 145 km long, to 25 km, dips 23-67 deg to the NW;
    trace listed from NE to SW (azimuth 230 deg), so its left-hand block is the SE one, the footwall;
    rake 155 deg (oblique reverse-right-lateral), peak slip 12.5 m; 300 nodes, 524 triangles
  - Papatea fault: Mw 6.46; 19 km long, to 25 km, dips 79-90 deg, mostly vertical;
    trace listed from N to S (azimuth 170 deg), so its left-hand block is the E one;
    rake -2 deg (left-lateral), peak slip 0.8 m; 27 nodes, 37 triangles
  - Hundalee fault: Mw 6.87; 44 km long, to 25 km, dips 84-90 deg, mostly vertical;
    trace listed from NNE to SSW (azimuth 206 deg), so its left-hand block is the ESE one;
    rake -114 deg (oblique normal-right-lateral), peak slip 3.3 m; 71 nodes, 113 triangles
  - North Leader fault: Mw 6.67; 26 km long, to 25 km, vertical;
    trace listed from NNE to SSW (azimuth 195 deg), so its left-hand block is the ESE one;
    rake -180 deg (right-lateral), peak slip 1.5 m; 31 nodes, 44 triangles
  - The Humps fault: Mw 7.14; 34 km long, to 25 km, dips 84-90 deg, mostly vertical;
    trace listed from ENE to WSW (azimuth 256 deg), so its left-hand block is the SSE one;
    rake 178 deg (right-lateral), peak slip 6.9 m; 74 nodes, 120 triangles
  - Stone Jug fault: Mw 6.50; 15 km long, to 25 km, dips 29-32 deg to the ENE;
    trace listed from SSE to NNW (azimuth 335 deg), so its left-hand block is the WSW one, the footwall;
    rake -169 deg (right-lateral), peak slip 1.6 m; 18 nodes, 23 triangles
  all faults: Mw 7.87 (the faults' moments summed).

Files
  *_nodes.csv      one row per mesh node. Slip is defined at the nodes and varies linearly over each
                   triangle between its three corners: this is what the inversion solved for.
  *_triangles.csv  one row per triangle: its corners, as node ids (node1-3 = rows of *_nodes.csv) and as
                   lon/lat/depth, its slip (the mean of its corners', i.e. the linear field's average over
                   the triangle; use these rows for a piecewise-constant model), its own plane's strike and
                   dip, and the rake.

Columns
  lon, lat         degrees, WGS84
  depth_km         km below the model's flat free surface, positive down
  slip_m           slip magnitude, m
  ss_m, ds_m       the inversion's own components, in the frame of each fault's trace as listed above:
                   ss_m > 0 is left-lateral, ds_m > 0 moves the trace's LEFT-hand block up-dip relative to
                   the right-hand one. Continuous along each fault: use these to map or interpolate slip.
  strike_deg, dip_deg, rake_deg  (triangles only)
                   Aki & Richards, from the triangle's own plane: strike clockwise from north with the
                   fault dipping to its right, dip 0-90, rake the hanging wall's slip relative to the
                   footwall measured in the plane from the strike direction (0 left-lateral, +-180
                   right-lateral, 90 reverse, -90 normal). A vertical triangle (dip within 0.01 deg of
                   90) takes its strike along the trace as listed.
                   Where a fault is nearly vertical its triangles tilt by fractions of a degree either way
                   (the trace curves), so this strike can flip by 180 deg between neighbours, and the sign
                   of the rake's dip-slip part with it, for the same motion. Map ss_m / ds_m instead.
  area_km2         (triangles only) the triangle's area

