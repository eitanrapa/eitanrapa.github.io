2019 Ridgecrest, California earthquake sequence: slip model
===========================================================

The 4 July (Mw 6.4) and 6 July (Mw 7.1) earthquakes together: two vertical fault sheets to 20 km depth in a layered crust (CRUST1.0), the north-west-striking fault of the Mw 7.1 (Valkaniotis's Sentinel-2 trace) and the north-east-striking fault of the Mw 6.4 (Ponti et al. 2020's mapped ruptures); ALOS-2 and Sentinel-1 InSAR (UCSD) spanning both events, Sentinel-2 offsets (Valkaniotis) and NGL GNSS; rank 45 by blocked cross-validation.
From https://eitanrapa.github.io/research/slip-models/ (exported 2026-11-04).

Faults (Mw from the inversion's own layered rigidity, as on the page; rake slip-weighted):
  - M7.1 fault: Mw 7.10; 51 km long, to 20 km, dips 81-90 deg, mostly vertical;
    trace listed from NW to SE (azimuth 139 deg), so its left-hand block is the NE one;
    rake 180 deg (right-lateral), peak slip 6.2 m; 356 nodes, 638 triangles
  - M6.4 fault (NE-striking): Mw 6.53; 23 km long, to 20 km, dips 77-90 deg, mostly vertical;
    trace listed from SW to NE (azimuth 44 deg), so its left-hand block is the NW one;
    rake 3 deg (left-lateral), peak slip 2.3 m; 175 nodes, 305 triangles
  all faults: Mw 7.14 (the faults' moments summed).

Files
  *_nodes.csv      one row per mesh node. Slip is defined at the nodes and varies linearly over each
                   triangle between its three corners: this is what the inversion solved for.
  *_triangles.csv  one row per triangle: its corners, as node ids (node1-3 = rows of *_nodes.csv) and as
                   lon/lat/depth, its slip (the mean of its corners', i.e. the linear field's average over
                   the triangle; use these rows for a piecewise-constant model), its own plane's strike and
                   dip, and the rake.

Columns
  lon, lat         degrees, WGS84
  depth_km         km below the model's flat free surface, positive down
  slip_m           slip magnitude, m
  ss_m, ds_m       the inversion's own components, in the frame of each fault's trace as listed above:
                   ss_m > 0 is left-lateral, ds_m > 0 moves the trace's LEFT-hand block up-dip relative to
                   the right-hand one. Continuous along each fault: use these to map or interpolate slip.
  strike_deg, dip_deg, rake_deg  (triangles only)
                   Aki & Richards, from the triangle's own plane: strike clockwise from north with the
                   fault dipping to its right, dip 0-90, rake the hanging wall's slip relative to the
                   footwall measured in the plane from the strike direction (0 left-lateral, +-180
                   right-lateral, 90 reverse, -90 normal). A vertical triangle (dip within 0.01 deg of
                   90) takes its strike along the trace as listed.
                   Where a fault is nearly vertical its triangles tilt by fractions of a degree either way
                   (the trace curves), so this strike can flip by 180 deg between neighbours, and the sign
                   of the rake's dip-slip part with it, for the same motion. Map ss_m / ds_m instead.
  area_km2         (triangles only) the triangle's area

