2021 Maduo, Qinghai earthquake: slip model
==========================================

The Kunlun Pass-Jiangcuo fault on Hu (2025)'s trace, dipping north at 90, 75, 75, 80, 85 and 85 degrees over six 33 km segments west to east, and a branch south of its eastern end dipping 80 degrees south, both to 25 km in a layered crust (CRUST1.0); Sentinel-1 interferograms on tracks 099, 106, 172, 033 and 026 (LiCSAR) and 004 (He et al. 2021), and 106 GNSS stations (Wang et al. 2022, 2024); rank 60 by blocked cross-validation. The bottom at 25 km is a modelling choice: Mw 7.43-7.47 for bottoms at 20-30 km.
From https://eitanrapa.github.io/research/slip-models/ (exported 2026-11-06).

Faults (Mw from the inversion's own layered rigidity, as on the page; rake slip-weighted):
  - Kunlun Pass–Jiangcuo fault: Mw 7.43; 197 km long, to 25 km, dips 68-90 deg to the N;
    trace listed from W to E (azimuth 98 deg), so its left-hand block is the N one, the hanging wall;
    rake -3 deg (left-lateral), peak slip 4.7 m; 885 nodes, 1616 triangles
  - Eastern branch: Mw 6.71; 35 km long, to 25 km, dips 77-82 deg to the SSW;
    trace listed from WNW to ESE (azimuth 101 deg), so its left-hand block is the NNE one, the footwall;
    rake 17 deg (left-lateral), peak slip 3.4 m; 233 nodes, 417 triangles
  all faults: Mw 7.45 (the faults' moments summed).

Files
  *_nodes.csv      one row per mesh node. Slip is defined at the nodes and varies linearly over each
                   triangle between its three corners: this is what the inversion solved for.
  *_triangles.csv  one row per triangle: its corners, as node ids (node1-3 = rows of *_nodes.csv) and as
                   lon/lat/depth, its slip (the mean of its corners', i.e. the linear field's average over
                   the triangle; use these rows for a piecewise-constant model), its own plane's strike and
                   dip, and the rake.

Columns
  lon, lat         degrees, WGS84
  depth_km         km below the model's flat free surface, positive down
  slip_m           slip magnitude, m
  ss_m, ds_m       the inversion's own components, in the frame of each fault's trace as listed above:
                   ss_m > 0 is left-lateral, ds_m > 0 moves the trace's LEFT-hand block up-dip relative to
                   the right-hand one. Continuous along each fault: use these to map or interpolate slip.
  strike_deg, dip_deg, rake_deg  (triangles only)
                   Aki & Richards, from the triangle's own plane: strike clockwise from north with the
                   fault dipping to its right, dip 0-90, rake the hanging wall's slip relative to the
                   footwall measured in the plane from the strike direction (0 left-lateral, +-180
                   right-lateral, 90 reverse, -90 normal). A vertical triangle (dip within 0.01 deg of
                   90) takes its strike along the trace as listed.
                   Where a fault is nearly vertical its triangles tilt by fractions of a degree either way
                   (the trace curves), so this strike can flip by 180 deg between neighbours, and the sign
                   of the rake's dip-slip part with it, for the same motion. Map ss_m / ds_m instead.
  area_km2         (triangles only) the triangle's area

